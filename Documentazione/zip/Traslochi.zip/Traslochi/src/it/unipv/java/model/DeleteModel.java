package it.unipv.java.model;

public class DeleteModel {
 	
	private String idInserito;
	private String cfInserito;
	
	public String getIdInserito() {
		return idInserito;
	}
	
	public String getCfInserito() {
		return cfInserito;
	}
	
	public void setId(String idDip) {
		idInserito= idDip;
	}
	
	public void setCf(String cf) {
		cfInserito= cf;
	}

}
