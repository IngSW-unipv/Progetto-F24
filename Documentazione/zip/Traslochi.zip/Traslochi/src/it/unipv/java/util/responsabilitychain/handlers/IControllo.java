package it.unipv.java.util.responsabilitychain.handlers;

import it.unipv.java.model.RegisterData;

public interface IControllo {
	public boolean controllaParametro(RegisterData datiRegistrazione);
	public void throwWarningView();
}
