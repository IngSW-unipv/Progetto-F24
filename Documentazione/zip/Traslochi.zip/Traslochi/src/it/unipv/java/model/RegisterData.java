package it.unipv.java.model;

public class RegisterData {
    private String nomeInserito;
    private String cognomeInserito;
    private String cfInserito;
    private String emailInserita;
    private String passwordInserita;
    private String confermaPasswordInserita;
    private String userId;
    
	
    public String getNomeInserito() {
		return nomeInserito;
	}
	public void setNomeInserito(String nomeInserito) {
		this.nomeInserito = nomeInserito;
	}
	public String getCognomeInserito() {
		return cognomeInserito;
	}
	public void setCognomeInserito(String cognomeInserito) {
		this.cognomeInserito = cognomeInserito;
	}
	public String getCfInserito() {
		return cfInserito;
	}
	public void setCfInserito(String cfInserito) {
		this.cfInserito = cfInserito;
	}
	public String getEmailInserita() {
		return emailInserita;
	}
	public void setEmailInserita(String emailInserita) {
		this.emailInserita = emailInserita;
	}
	public String getPasswordInserita() {
		return passwordInserita;
	}
	public void setPasswordInserita(String passwordInserita) {
		this.passwordInserita = passwordInserita;
	}
	public String getConfermaPasswordInserita() {
		return confermaPasswordInserita;
	}
	public void setConfermaPasswordInserita(String confermaPasswordInserita) {
		this.confermaPasswordInserita = confermaPasswordInserita;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
    
    
}
