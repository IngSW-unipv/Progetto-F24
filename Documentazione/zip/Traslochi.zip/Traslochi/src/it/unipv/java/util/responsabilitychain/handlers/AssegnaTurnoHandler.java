package it.unipv.java.util.responsabilitychain.handlers;

public class AssegnaTurnoHandler {

}
