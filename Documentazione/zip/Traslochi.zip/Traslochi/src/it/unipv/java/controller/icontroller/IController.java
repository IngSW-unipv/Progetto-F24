package it.unipv.java.controller.icontroller;

import javax.swing.JFrame;

public interface IController {
	public JFrame getView();
}
