package it.unipv.test;

public class RegisterControllerTest {
public RegisterControllerTest() {
      // TODO implement this operation
      throw new UnsupportedOperationException("not implemented");
   }
   
   
}
