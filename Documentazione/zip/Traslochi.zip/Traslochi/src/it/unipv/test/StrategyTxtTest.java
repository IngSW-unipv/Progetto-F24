package it.unipv.test;
/*
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import it.unipv.java.persistance.DaoFactory;
*/
public class StrategyTxtTest {
/*
	private RegisterModel registra;
	private UserModel user;
	@Before
	public void init() {
		user = new UserModel();
		user.setId("IDPROVAREGISTR");
		user.setNome("NomeProva");
		user.setCognome("CognomeProva");
		user.setCf("CFPROVA");
		user.setEmail("NomeProva.CognomeProva@qualcosa.com");
		user.setPassword("PasswordProva");
		user.setUserType(UserType.CLIENTE);
		registra = new RegisterModel(user);
	}

//	TEST PER VERIFICARE CHE FUNZIONI UN TIPO TI PERMANENZA TXT, MODIFICARE PROPERTIES PRIMA DI EXEC:
//	Persistance_Type = MySql
	@Test
	public void testTxtCliente() {
		assertTrue("Strategia Sbagliata",DaoFactory.getInstance().getClientePersistance().createCliente(registra));
	}
	*/
}
