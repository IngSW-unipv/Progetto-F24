package it.unipv.test;

public class PrenotazioneTest {

	public PrenotazioneTest() {
      // TODO implement this operation
      throw new UnsupportedOperationException("not implemented");
   }
   

	public static void main(String[] args) {
	/*	PrenotazioneModel pm;
		PrenotazioneView pv;
		PrenotazioneController pc;
		WarningView wv;
		ClienteView cv;
		
		pm = new PrenotazioneModel();
		pm.setIndirizzodiRitiro("Via Celentano");
		pm.setIndirizzoDiConsegna("Via Roma");
		pm.setDataRitiro("24/11/2024");
		pm.setDataConsegna("27/11/2024");
		pm.setCVC("366");
		pm.setScadGiorno("28");
		pm.setScadMese("07");
		pm.setScadAnno("2024");
		
		pv = new PrenotazioneView();
		pv.setViewTest(pm);		//Riempie La View con i parametri specificati
		pc = new PrenotazioneController(pm, pv);
		pv.setVisible(true);
*/
		System.out.println("Hello World!");
	}
}

