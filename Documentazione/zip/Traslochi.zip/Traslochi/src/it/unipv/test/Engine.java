package it.unipv.test;

import it.unipv.java.util.controllerpila.ControllerGestor;

//import it.unipv.java.controller.LoginController;
//import it.unipv.java.view.LoginView;

public class Engine {

	public static void main(String[] args) {
		ControllerGestor.getInstance();
	}
	
}